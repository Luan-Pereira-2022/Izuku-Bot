<p align="center">
<img src="https://telegra.ph/file/5bd80998f8262a0a5e64f.jpg" alt="Ichigo Kurosaki" width="500"/>

Base Bot WhatsApp Multi Device With [`Baileys Multi Device`](https://github.com/adiwajshing)

## Note
Base Ini Free Untuk Semua, Tidak Untuk Diperjualbelikan Kecuali Lu Udah Tambahin Fitur Langka Di Script Ini Baru Boleh Jual

## Thanks To
* [`Adiwajshing`](https://github.com/adiwajshing)
* [`Nurutomo`](https://github.com/Nurutomo)
* [`Fandyyy`](https://github.com/FBOTZ-YT)
* [`Ferdi`](https://github.com/FERDIZ-afk)

## Connect With Me
* [`Whatsapp`](https://wa.me/6285609233482?text=Assalamualaikum)
* [`Instagram`](https://instagram.com/_nzrlafndi)
* [`More...`](https://linktr.ee/NzrlAfndi)

## Donate Me
* [`Saweria`](https://saweria.co/Fandyy)
* [`Gopay`](https://telegra.ph/file/4abd43eeab0c17edebff2.jpg)

## License
License: [MIT](https://en.wikipedia.org/wiki/MIT_License)

## UNTUK PENGGUNA WINDOWS/RDP

* Unduh & Instal Git [`Klik Disini`](https://git-scm.com/downloads)
* Unduh & Instal NodeJS [`Klik Disini`](https://nodejs.org/en/download)
* Unduh & Instal FFmpeg [`Klik Disini`](https://ffmpeg.org/download.html) (**Jangan Lupa Tambahkan FFmpeg ke variabel lingkungan PATH**)


```bash
git clone https://github.com/NzrlAfndi/Ichigo-Kurosaki
cd Ichigo-Kurosaki
npm install
```


## FOR HEROKU USER
# Install Buildpack
- heroku/nodejs
- https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest.git
- https://github.com/clhuang/heroku-buildpack-webp-binaries.git


## FOR TERMUX/UBUNTU/SSH USER

```bash
apt update && apt upgrade
apt install git -y
apt install nodejs -y
apt install ffmpeg -y
git clone https://github.com/NzrlAfndi/Ichigo-Kurosaki
cd Ichigo-Kurosaki
npm install
```

## Installing
```bash
$ node .
```

## ❗ Warning
WhatsApp bot is still in the development stage, so there are a few bugs
WhatsApp Connection (BETA, not working perfectly)

Editing Number Owner And More On [`settings.js`](https://github.com/NzrlAfndi/Ichigo-Kurosaki/blob/master/settings.js)


